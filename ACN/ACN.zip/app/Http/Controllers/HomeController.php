<?php
    namespace App\Http\Controllers;

    use Illuminate\Http\Request;

    class HomeController extends Controller
    {
        public function __invoke() {
            return view('inicio');
        }
        public function inicio(){
            return view('inicio');
        }
    }
?>