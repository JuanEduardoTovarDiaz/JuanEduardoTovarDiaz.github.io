@extends('layouts.plantilla')

@section('title', 'ACN | Bolsa de Trabajo')

@section('content')

    <!-- BANNER NUESTROS SERVICIOS -->
    <div class="jumbotron jumbotron-fluid bolsatrabajo_banner" style="padding: 9% 0% 9% 0%">
        <div class="container">
            <h1 class="display-4 text-center"><span>BOLSA DE TRABAJO</span></h1>
            <p class="lead text-center"><span>Asesores Contables Narváez S.C.</span></p>
        </div>
    </div>

    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
@endsection()