@extends('layouts.plantilla')

@section('title', 'ACN | Página en Construcción')

@section('content')

    <div style="height: 600px;">
        
    </div>
            
@endsection()