<?php

    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];
    $email = $_POST['email'];
    $emailConfirmacion = $_POST['emailConfirmacion'];
    $telefono = $_POST['telefono'];
    $empresa = $_POST['empresa'];
    $mensaje = $_POST['mensaje'];

    $header = "From: " . $email . " \r\n";
    $header = "X-Mailer: PHP/" . phpversion() . " \r\n";
    $header = "Mime-Version: 1:0 \r\n";
    $header = "Content-Type: text/plain";
    
    $mensaje = "Este mensaje fue enviado por: " . $nombre . " " . $apellido ." \r\n";
    $mensaje = "Su e-mail es: " . $mensaje . " \r\n";
    $mensaje = "Teléfono de contacto: " . $telefono . " \r\n";
    $mensaje = "Empresa proveniente: " . $empresa . " \r\n";
    $mensaje = "Mensaje: " . $_POST['mensaje'] . " \r\n";
    $mensaje = "Enviado el: " . date('d/m/Y', time());

    $para = '1830040@upv.edu.mx';
    $asunto = 'Consultoría';

    mail($para, $asunto, utf8_decode($mensaje), $header);
    header('inicio');
?>