

<?php $__env->startSection('title', 'ACN | Bolsa de Trabajo'); ?>

<?php $__env->startSection('content'); ?>

    <!-- BANNER NUESTROS SERVICIOS -->
    <div class="jumbotron jumbotron-fluid bolsatrabajo_banner" style="padding: 9% 0% 9% 0%">
        <div class="container">
            <h1 class="display-4 text-center"><span>BOLSA DE TRABAJO</span></h1>
            <p class="lead text-center"><span>Asesores Contables Narváez S.C.</span></p>
        </div>
    </div>

    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\salda\Documents\xampp\htdocs\ACN\resources\views/bolsa_trabajo/bolsa_trabajo.blade.php ENDPATH**/ ?>